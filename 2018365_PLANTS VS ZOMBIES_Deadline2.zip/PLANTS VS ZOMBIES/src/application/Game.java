package application;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;



import javafx.animation.PathTransition;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import javafx.util.Duration;


public class Game implements Initializable{
	private int sunscore=25;
	
	@FXML
	private Label lblstatus;
	
	@FXML
	private TextField txtusername;
	
	@FXML
	private Button sun;
	@FXML
	private Label Timer;
	@FXML
	private ImageView zombie1;
	@FXML
	private ImageView zombie2;
	@FXML
	private ImageView Lawnmover;
	
	@FXML
	private Button menu;
	
	
	/*class bg_thread implements Runnable{
		@Override
		public void run() {
			for(int i =0;i<100;i++) {
				
				try {
					Time.setProgress(1/100.0);
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	public void TIMER(ActionEvent event) {
		Thread th = new Thread(new bg_thread());
		th.start();
	}
	
	*/
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		//Time.setProgress(0.0);
		Line line = new Line(0,0,-1120,0);
		Line l1 = new Line(0,0,-1120,0);
		Line lines = new Line(100,100,500,800);
		PathTransition path = new PathTransition();
		PathTransition paths = new PathTransition();
		PathTransition p1 = new PathTransition();
		path.setNode(zombie1);
		p1.setNode(zombie2);
		paths.setNode(sun);
		path.setPath(line);
		paths.setPath(lines);
		p1.setPath(l1);
		path.setDuration(new Duration(5000));
		p1.setDuration(new Duration(5000));
		paths.setDuration(new Duration(10000));
		path.setCycleCount(1);
		p1.setCycleCount(1);
		paths.setCycleCount(1000);
		path.setRate(0.1);
		p1.setRate(0.1);
		paths.setRate(0.5);
		paths.play();
		int count=0;
		do {
			path.play();
			count++;
		}while(count!=1);
		if(count==1) {
		p1.play();
		}
		
		
		
    }
	
	
	public void movezombie() {
		
	}
	
	
	public int getsunscore() {
		return sunscore;
	}
	
	public void setsunscore(int sunscore) {
		this.sunscore = sunscore+25;
		Timer.setText(Integer.toString(sunscore));
	
	}
	
	@FXML
	public void profile(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/application/main.fxml"));
		Scene scene = new Scene(root);
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		app_stage.setScene(scene);
		app_stage.show();
		
		
	}
	
	
	
	@FXML
	public void username(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/application/UserName.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		app_stage.setScene(scene);
		app_stage.show();
		
		
		
		
		
	}
	
	@FXML
	public void play(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/application/Graphics.fxml"));
		Scene scene = new Scene(root);
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene.getStylesheets().add(getClass().getResource("application2.css").toExternalForm());
		app_stage.setScene(scene);
		app_stage.show();
		
	}
	
	@FXML
	public void resume(ActionEvent event) throws Exception {
		
		
	}
	@FXML
	public void exit(ActionEvent event) throws Exception {
		Stage app_stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/application/Warning.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application3.css").toExternalForm());
		app_stage.setScene(scene);
		app_stage.setTitle("PLANTS VS ZOMBIES");
		app_stage.show();
		
	}
	public void exitscreen(ActionEvent event) {
		System.exit(0);
	}
	
	@FXML
	public void menu(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/application/Graphics.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application2.css").toExternalForm());
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		app_stage.setScene(scene);
		app_stage.show();
		
	}
	@FXML
	public void changeuser(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/application/UserName.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		app_stage.setScene(scene);
		app_stage.show();
		
	}
	@FXML
	public void differentlevel(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/application/Differentlevel.fxml"));
		Scene scene = new Scene(root);
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene.getStylesheets().add(getClass().getResource("application2.css").toExternalForm());
		app_stage.setScene(scene);
		app_stage.show();
		
	}
	@FXML
	public void level1(ActionEvent event) throws Exception {
		
		Parent root = FXMLLoader.load(getClass().getResource("/application/Level1.fxml"));
		Scene scene = new Scene(root);
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene.getStylesheets().add(getClass().getResource("application1.css").toExternalForm());
		
		app_stage.setScene(scene);
		app_stage.show();
		
	}
	
	public void addsunscore(ActionEvent event) throws Exception {
		int score = getsunscore();
		setsunscore(score);
	}
		
	
	@FXML
	public void level2(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/application/level2.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application1.css").toExternalForm());
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		app_stage.setScene(scene);
		app_stage.show();
		
	}

	@FXML
	public void level3(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/application/level3.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application1.css").toExternalForm());
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		app_stage.setScene(scene);
		app_stage.show();
		
	}
	@FXML
	public void level4(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/application/level4.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application1.css").toExternalForm());
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		app_stage.setScene(scene);
		app_stage.show();
		
	}
	@FXML
	public void level5(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/application/level5.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application1.css").toExternalForm());
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		app_stage.setScene(scene);
		app_stage.show();
		
	}

}

///////////////////////////////////////////////////////////////////////////////////////
abstract class Plants extends Game{
	public void clickpea() {
		
	}
}


class Peashooter extends Plants{
	
	
}

class Freezepeashooter extends Plants {
	
}


class Wallnut extends Plants{
	
}


class Cherrybomb extends Plants{
	
}


class Sunflower extends Plants{
	
}


//////////////////////////////////////////////////////////////////////////

abstract class Zombies{
	

	
	
	
	
}
class NormalZombie extends Zombies{
	
	
	
	
}
class cloneheadZombie extends Zombies{
	
	
	
	
	
	
}

/////////////////////////////////////////////////////////////////////////////////////

class Lawnmover extends Game{
	
	
	
	
}

////////////////////////////////////////////////////////////////////////////////////////

class Sun extends Game{
	
	
	
	
	
}
