package application;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class Game implements Initializable{
	@FXML
	private Label lblstatus;
	
	@FXML
	private TextField txtusername;
	
	@FXML
	private Button level1;
	
	
	@Override
	public void initialize(URL url, ResourceBundle rb) {
        // TODO
    } 
	
	ArrayList<TextField> list = new ArrayList<TextField>();
	
	@FXML
	public void profile(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/application/main.fxml"));
		Scene scene = new Scene(root);
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		app_stage.setScene(scene);
		app_stage.show();
		
		
	}
	
	@FXML
	public void newgame(ActionEvent event) throws Exception {
		
		Parent root = FXMLLoader.load(getClass().getResource("/application/Level1.fxml"));
		Scene scene = new Scene(root);
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene.getStylesheets().add(getClass().getResource("application1.css").toExternalForm());
		app_stage.setScene(scene);
		app_stage.show();
		
	}
	@FXML
	public void username(ActionEvent event) throws Exception {
		
		Parent root = FXMLLoader.load(getClass().getResource("/application/UserName.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		app_stage.setScene(scene);
		app_stage.show();
		
		
	}
	@FXML
	public void play(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/application/Graphics.fxml"));
		Scene scene = new Scene(root);
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		app_stage.setScene(scene);
		app_stage.show();
		
	}
	
	
	
	@FXML
	public void resume(ActionEvent event) throws Exception {
		
		
	}
	@FXML
	public void exit(ActionEvent event) {
		System.exit(0);
	}
	@FXML
	public void menu(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/application/Graphics.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		app_stage.setScene(scene);
		app_stage.show();
		
	}
	@FXML
	public void changeuser(ActionEvent event) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/application/UserName.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		app_stage.setScene(scene);
		app_stage.show();
		
	}

}

///////////////////////////////////////////////////////////////////////////////////////
class Plants{
	
}


class Peashooter extends Plants{
	
}

class Freezepeashooter extends Plants {
	
}




//////////////////////////////////////////////////////////////////////////

class Zombies{
	

	
	
	
	
}
class NormalZombie extends Zombies{
	
	
	
	
}
class cloneheadZombie extends Zombies{
	
	
	
	
	
	
}

/////////////////////////////////////////////////////////////////////////////////////

class Lawnmover{
	
	
	
	
}

////////////////////////////////////////////////////////////////////////////////////////

class Sun{
	
	
	
	
}
